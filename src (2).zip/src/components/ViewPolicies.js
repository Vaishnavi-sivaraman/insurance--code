// import React, { useState, useEffect } from 'react';
// import { Link } from 'react-router-dom';
// import axios from 'axios';

// const ViewPolicies = () => {
//   const [planTypes, setPlanTypes] = useState([]);

//   useEffect(() => {
//     axios.get('http://localhost:8080/api/insurance')
//       .then(response => setPlanTypes(response.data))
//       .catch(error => console.error(error));
//   }, []);

//   return (
//     <div>
//       <h1>Insurance Plans</h1>
//       <ul>
//         {planTypes.map(plan => (
//           <li key={plan.planId}>
//             <Link to={`/customer/policies/${plan.planType}`}>{plan.planType}</Link>
//           </li>
//         ))}
//       </ul>
//     </div>
//   );
// };

// export default ViewPolicies;

import React, { useState, useEffect, useContext } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { UserContext } from '../UserContext';

const ViewPolicies = () => {
    const [planTypes, setPlanTypes] = useState([]);
    const { user } = useContext(UserContext);

    useEffect(() => {
        axios.get('http://localhost:8080/api/insurance')
            .then(response => setPlanTypes(response.data))
            .catch(error => console.error(error));
    }, []);

    return (
        <div>
            <h1>Insurance Plans</h1>
            <ul>
                {planTypes.map(plan => (
                    <li key={plan.planId}>
                        <Link to={`/customer/policies/${plan.planType}`} state={{ userName: user.userName }}>
                            {plan.planType}
                        </Link>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default ViewPolicies;
