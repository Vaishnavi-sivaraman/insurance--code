// // import React, { useState, useEffect } from 'react';
// // import { useParams, useNavigate } from 'react-router-dom';
// // import axios from 'axios';

// // const PolicyDetails = () => {
// //   const { planType } = useParams();
// //   const [policies, setPolicies] = useState([]);
// //   const navigate = useNavigate();

// //   useEffect(() => {
// //     axios.get(`http://localhost:8080/api/policies/planType/${planType}`)
// //       .then(response => setPolicies(response.data))
// //       .catch(error => console.error(error));
// //   }, [planType]);

// //   const handleApply = (policy) => {
// //     navigate(`/customer/apply/${policy.policyId}`);
// //   };

// //   return (
// //     <div>
// //       <h1>{planType} Policies</h1>
// //       <table>
// //         <thead>
// //           <tr>
// //             <th>Policy Name</th>
// //             <th>Description</th>
// //             <th>Period</th>
// //             <th>Action</th>
// //           </tr>
// //         </thead>
// //         <tbody>
// //           {policies.map(policy => (
// //             <tr key={policy.policyId}>
// //               <td>{policy.policyName}</td>
// //               <td>{policy.description}</td>
// //               <td>{policy.period}</td>
// //               <td><button onClick={() => handleApply(policy)}>Apply</button></td>
// //             </tr>
// //           ))}
// //         </tbody>
// //       </table>
// //     </div>
// //   );
// // };

// // export default PolicyDetails;

// import React, { useState, useEffect } from 'react';
// import { useParams, useNavigate } from 'react-router-dom';
// import axios from 'axios';

// const PolicyDetails = () => {
//   const { planType } = useParams();
//   const [policies, setPolicies] = useState([]);
//   const navigate = useNavigate();

//   useEffect(() => {
//     axios.get(`http://localhost:8080/api/policies/planType/${planType}`)
//       .then(response => setPolicies(response.data))
//       .catch(error => console.error(error));
//   }, [planType]);

//   const handleApply = (policy) => {
//     navigate(`/customer/apply/${policy.policyId}`);
//   };

//   return (
//     <div>
//       <h1>{planType} Policies</h1>
//       <table>
//         <thead>
//           <tr>
//             <th>Policy Name</th>
//             <th>Description</th>
//             <th>Period</th>
//             <th>Action</th>
//             <th>Brochure</th>
//           </tr>
//         </thead>
//         <tbody>
//           {policies.map(policy => (
//             <tr key={policy.policyId}>
//               <td>{policy.policyName}</td>
//               <td>{policy.description}</td>
//               <td>{policy.period}</td>
//               <td><button onClick={() => handleApply(policy)}>Apply</button></td>
//               <td>
//                 <a href={`/${policy.policyId}.pdf`} download={`${policy.policyName}_brochure.pdf`}>
//                   Download Brochure
//                 </a>
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// };

// export default PolicyDetails;

//now
// import React, { useState, useEffect } from 'react';
// import { useParams, useNavigate } from 'react-router-dom';
// import axios from 'axios';

// const PolicyDetails = () => {
//   const { planType } = useParams();
//   const [policies, setPolicies] = useState([]);
//   const navigate = useNavigate();

//   useEffect(() => {
//     axios.get(`http://localhost:8080/api/policies/planType/${planType}`)
//       .then(response => setPolicies(response.data))
//       .catch(error => console.error(error));
//   }, [planType]);

//   const handleApply = (policy) => {
//     navigate(`/customer/apply/${policy.policyId}`, { state: { policyName: policy.policyName, planType } });
//   };

//   return (
//     <div>
//       <h1>{planType} Policies</h1>
//       <table>
//         <thead>
//           <tr>
//             <th>Policy Name</th>
//             <th>Description</th>
//             <th>Period</th>
//             <th>Action</th>
//             <th>Brochure</th>
//           </tr>
//         </thead>
//         <tbody>
//           {policies.map(policy => (
//             <tr key={policy.policyId}>
//               <td>{policy.policyName}</td>
//               <td>{policy.description}</td>
//               <td>{policy.period}</td>
//               <td><button onClick={() => handleApply(policy)}>Apply</button></td>
//               <td>
//                 <a href={`/${policy.policyId}.pdf`} download={`${policy.policyName}_brochure.pdf`}>
//                   Download Brochure
//                 </a>
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// };

// export default PolicyDetails;

import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';

const PolicyDetails = () => {
    const { planType } = useParams();
    const [policies, setPolicies] = useState([]);
    const navigate = useNavigate();
    const location = useLocation();
    const { userName } = location.state || {};

    useEffect(() => {
        axios.get(`http://localhost:8080/api/policies/planType/${planType}`)
            .then(response => setPolicies(response.data))
            .catch(error => console.error(error));
    }, [planType]);

    const handleApply = (policy) => {
        navigate(`/customer/apply/${policy.policyId}`, { state: { policyName: policy.policyName, planType, userName } });
    };

    return (
        <div>
            <h1>{planType} Policies</h1>
            <table>
                <thead>
                    <tr>
                        <th>Policy Name</th>
                        <th>Description</th>
                        <th>Period</th>
                        <th>Action</th>
                        <th>Brochure</th>
                    </tr>
                </thead>
                <tbody>
                    {policies.map(policy => (
                        <tr key={policy.policyId}>
                            <td>{policy.policyName}</td>
                            <td>{policy.description}</td>
                            <td>{policy.period}</td>
                            <td><button onClick={() => handleApply(policy)}>Apply</button></td>
                            <td>
                                <a href={`/${policy.policyId}.pdf`} download={`${policy.policyName}_brochure.pdf`}>
                                    Download Brochure
                                </a>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default PolicyDetails;

