import React, { useState } from 'react';
 
const PremiumCalculator = () => {
  const [coverageAmount, setCoverageAmount] = useState('');
  const [term, setTerm] = useState('6');
  const [period, setPeriod] = useState('5');
  const [premium, setPremium] = useState('');
 
  const calculatePremium = () => {
    let calculatedPremium = 0;
    if (term === '6') {
      calculatedPremium = coverageAmount / (period * 2);
    } else if (term === '12') {
      calculatedPremium = coverageAmount / period;
    }
    setPremium(calculatedPremium);
  };
 
  return (
    <div>
      <h2>Premium Calculator</h2>
      <label htmlFor="coverageAmount">Coverage Amount:</label>
      <input
        type="number"
        value={coverageAmount}
        onChange={(e) => setCoverageAmount(e.target.value)}
        placeholder="Enter coverage amount"
      />
      <label htmlFor="term">Term:</label>
      <select value={term} onChange={(e) => setTerm(e.target.value)}>
        <option value="6">6</option>
        <option value="12">12</option>
      </select>
      <label htmlFor="period">Period:</label>
      <select value={period} onChange={(e) => setPeriod(e.target.value)}>
        <option value="5">5</option>
        <option value="10">10</option>
      </select>
      <button onClick={calculatePremium}>Calculate Premium</button>
      {premium && <div>Premium Amount: ₹{premium.toFixed(2)}</div>}
    </div>
  );
};
 
export default PremiumCalculator;