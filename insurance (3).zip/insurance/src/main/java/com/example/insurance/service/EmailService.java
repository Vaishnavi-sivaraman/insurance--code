package com.example.insurance.service;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.mail.SimpleMailMessage;
//import org.springframework.mail.javamail.JavaMailSender;
//import org.springframework.stereotype.Service;
//
//@Service
//public class EmailService {
//
//    @Autowired
//    private JavaMailSender mailSender;
//
//    public void sendEmail(String to, String subject, String text) {
//        SimpleMailMessage message = new SimpleMailMessage();
//        message.setTo(to);
//        message.setSubject(subject);
//        message.setText(text);
//        mailSender.send(message);
//    }
//}

import com.example.insurance.model.AppliedPolicy;
import com.example.insurance.model.User;
import com.example.insurance.repository.AppliedPolicyRepository;
import com.example.insurance.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class EmailService {

    @Autowired
    private AppliedPolicyRepository appliedPolicyRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JavaMailSender emailSender;

    public void sendPaymentReminderEmails() {
        LocalDate today = LocalDate.now();
        LocalDate tomorrow = today.plusDays(1);

        // Fetch policies where the next payment date is tomorrow
        List<AppliedPolicy> policies = appliedPolicyRepository.findByNextPaymentDate(tomorrow);

        for (AppliedPolicy policy : policies) {
            // Find the user associated with the policy
            Optional<User> user = userRepository.findByUserName(policy.getUserName());
            if (user.isPresent()) {
                // Send email to the user's email address
                sendEmailReminder(user.get().getEmail(), policy);
            }
        }
    }

    private void sendEmailReminder(String toEmail, AppliedPolicy policy) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(toEmail);
        message.setSubject("Payment Reminder");
        message.setText("Dear Customer,\n\nYour payment is due tomorrow for policy: "
                + policy.getPolicyName()
                + ".\n\nThank you for choosing our services.\n\nBest Regards,\nYour Insurance Company");

        emailSender.send(message);
    }


}
