package com.example.insurance.repository;

import com.example.insurance.model.AppliedPolicy;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
//public interface AppliedPolicyRepository extends JpaRepository<AppliedPolicy, Long> {
//    List<AppliedPolicy> findByStatus(String status);
//    AppliedPolicy findFirstByOrderByAppliedPolicyIdDesc();
//}
public interface AppliedPolicyRepository extends JpaRepository<AppliedPolicy, Long> {
    List<AppliedPolicy> findByStatus(String status);
    List<AppliedPolicy> findByUserName(String userName);
    @Query(value = "SELECT * FROM appliedPolicy ORDER BY appliedPolicyId DESC LIMIT 1", nativeQuery = true)
    AppliedPolicy findFirstByOrderByAppliedPolicyIdDesc();


    List<AppliedPolicy> findByNextPaymentDate(LocalDate nextPaymentDate);
}


