package com.example.insurance.service;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.mail.SimpleMailMessage;
//import org.springframework.mail.javamail.JavaMailSender;
//import org.springframework.stereotype.Service;
//
//@Service
//public class EmailService {
//
//    @Autowired
//    private JavaMailSender mailSender;
//
//    public void sendEmail(String to, String subject, String text) {
//        SimpleMailMessage message = new SimpleMailMessage();
//        message.setTo(to);
//        message.setSubject(subject);
//        message.setText(text);
//        mailSender.send(message);
//    }
//}

import com.example.insurance.model.AppliedPolicy;
import com.example.insurance.model.User;
import com.example.insurance.repository.AppliedPolicyRepository;
import com.example.insurance.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.nio.file.AtomicMoveNotSupportedException;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;

//@Service
//public class EmailService {
//
//    @Autowired
//    private AppliedPolicyRepository appliedPolicyRepository;
//
//    @Autowired
//    private UserRepository userRepository;
//
//    @Autowired
//    private JavaMailSender emailSender;
//
//    public void sendPaymentReminderEmails() {
//        LocalDate today = LocalDate.now();
//        LocalDate tomorrow = today.plusDays(1);
//
//        // Fetch policies where the next payment date is tomorrow
//        List<AppliedPolicy> policies = appliedPolicyRepository.findByNextPaymentDate(tomorrow);
//
//        for (AppliedPolicy policy : policies) {
//            // Find the user associated with the policy
//            Optional<User> user = userRepository.findByUserName(policy.getUserName());
//            if (user.isPresent()) {
//                // Send email to the user's email address
//                sendEmailReminder(user.get().getEmail(), policy);
//            }
//        }
//    }
//
//    private void sendEmailReminder(String toEmail, AppliedPolicy policy) {
//        SimpleMailMessage message = new SimpleMailMessage();
//        message.setTo(toEmail);
//        message.setSubject("Payment Reminder");
//        message.setText("Dear Customer,\n\nYour payment is due tomorrow for policy: "
//                + policy.getPolicyName()
//                + ".\n\nThank you for choosing our services.\n\nBest Regards,\nYour Insurance Company");
//
//        emailSender.send(message);
//    }
//
//
//}
//@Service
//public class EmailService {
//
//    @Autowired
//    private JavaMailSender mailSender;
//
//    @Autowired
//    private AppliedPolicyRepository appliedPolicyRepository;
//
//    @Autowired
//    private UserRepository userRepository;
//
//    @Scheduled(cron = "0 * * * * ?") // Every day at 10 AM
//    public void sendPaymentReminderEmails() {
//        Date today = new Date();
//        Date tomorrow = new Date(today.getTime() + (1000 * 60 * 60 * 24)); // Add one day
//
//        List<AppliedPolicy> policies = appliedPolicyRepository.findByNextPaymentDate(tomorrow);
//        for (AppliedPolicy policy : policies) {
//            String email = userRepository.findByUserName(policy.getUserName()).get().getEmail();
//            sendEmail(email, "Payment Reminder", "Your next payment is due tomorrow.");
//        }
//    }
//
////    private void sendEmail(String to, String subject, String text) {
////        SimpleMailMessage message = new SimpleMailMessage();
////        message.setTo(to);
////        message.setSubject(subject);
////        message.setText(text);
////        mailSender.send(message);
////    }
//private void sendEmail(String to, String subject, String text) {
//    try {
//        System.out.println("hey here");
//        SimpleMailMessage message = new SimpleMailMessage();
//        message.setTo(to);
//        message.setSubject(subject);
//        message.setText(text);
//        mailSender.send(message);
//        System.out.println("Email sent successfully to " + to);
//    } catch (Exception e) {
//        System.err.println("Error sending email: " + e.getMessage());
//    }
//}
//
//}

//@Service
//public class EmailService {
//
//    @Autowired
//    private JavaMailSender mailSender;
//
//    @Autowired
//    private AppliedPolicyRepository appliedPolicyRepository;
//
//    @Autowired
//    private UserRepository userRepository;
//
//    @Scheduled(cron = "0 * * * * ?") // Every minute
//    public void sendPaymentReminderEmails() {
//        try {
//            System.out.println("Scheduler triggered");
//            Date today = new Date();
//            Date tomorrow = new Date(today.getTime() + (1000 * 60 * 60 * 24)); // Add one day
//
//            System.out.println("Today: " + today);
//            System.out.println("Tomorrow: " + tomorrow);
//
//            List<AppliedPolicy> policies = appliedPolicyRepository.findByNextPaymentDate(tomorrow);
//            System.out.println("Policies found: " + policies.size());
//
//            for (AppliedPolicy policy : policies) {
//                System.out.println("Processing policy: " + policy.getPolicyName() + " for user " + policy.getUserName());
//                Optional<User> userOptional = userRepository.findByUserName(policy.getUserName());
//                if (userOptional.isPresent()) {
//                    String email = userOptional.get().getEmail();
//                    System.out.println("Sending email to: " + email);
//                    sendEmail(email, "Payment Reminder", "Your next payment is due tomorrow.");
//                } else {
//                    System.out.println("User not found for policy: " + policy.getPolicyName());
//                }
//            }
//        } catch (Exception e) {
//            System.err.println("Error in sendPaymentReminderEmails: " + e.getMessage());
//        }
//    }
//
//    private void sendEmail(String to, String subject, String text) {
//        try {
//            System.out.println("hey here");
//            SimpleMailMessage message = new SimpleMailMessage();
//            message.setTo(to);
//            message.setSubject(subject);
//            message.setText(text);
//            mailSender.send(message);
//            System.out.println("Email sent successfully to " + to);
//        } catch (Exception e) {
//            System.err.println("Error sending email: " + e.getMessage());
//        }
//    }
//}

//@Service
//public class EmailService {
//
//    @Autowired
//    private JavaMailSender mailSender;
//
//    @Autowired
//    private AppliedPolicyRepository appliedPolicyRepository;
//
//    @Autowired
//    private UserRepository userRepository;
//
//    @Scheduled(cron = "0 * * * * ?") // Every minute
//    public void sendPaymentReminderEmails() {
//        try {
//            System.out.println("Scheduler triggered");
//            Date today = new Date();
//            Date tomorrow = new Date(today.getTime() + (1000 * 60 * 60 * 24)); // Add one day
//
//            System.out.println("Today: " + today);
//            System.out.println("Tomorrow: " + tomorrow);
//
//            List<AppliedPolicy> policies = appliedPolicyRepository.findByNextPaymentDate(tomorrow);
//            System.out.println(policies);
//            System.out.println("Policies found: " + policies.size());
//
//            for (AppliedPolicy policy : policies) {
//                System.out.println("Processing policy: " + policy.getPolicyName() + " for user " + policy.getUserName());
//                Optional<User> userOptional = userRepository.findByUserName(policy.getUserName());
//                if (userOptional.isPresent()) {
//                    String email = userOptional.get().getEmail();
//                    System.out.println("Sending email to: " + email);
//                    sendEmail(email, "Payment Reminder", "Your next payment is due tomorrow.");
//                } else {
//                    System.out.println("User not found for policy: " + policy.getPolicyName());
//                }
//            }
//        } catch (Exception e) {
//            System.err.println("Error in sendPaymentReminderEmails: " + e.getMessage());
//        }
//    }
//
//    private void sendEmail(String to, String subject, String text) {
//        try {
//            System.out.println("hey here");
//            SimpleMailMessage message = new SimpleMailMessage();
//            message.setTo(to);
//            message.setSubject(subject);
//            message.setText(text);
//            mailSender.send(message);
//            System.out.println("Email sent successfully to " + to);
//        } catch (Exception e) {
//            System.err.println("Error sending email: " + e.getMessage());
//        }
//    }
//}

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

//import java.sql.Date;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;

//@Service
//public class EmailService {
//
//    @Autowired
//    private JavaMailSender mailSender;
//
//    @Autowired
//    private AppliedPolicyRepository appliedPolicyRepository;
//
//    @Autowired
//    private UserRepository userRepository;
//
//    @Scheduled(cron = "0 * * * * ?") // Every minute
//    public void sendPaymentReminderEmails() {
//        try {
//            System.out.println("Scheduler triggered");
//            java.util.Date today = new java.util.Date();
//            Calendar calendar = Calendar.getInstance();
//            calendar.setTime(today);
//            calendar.add(Calendar.DAY_OF_YEAR, 1);
//            java.sql.Date tomorrow = new java.sql.Date(calendar.getTimeInMillis());
//
//            System.out.println("Today: " + today);
//            System.out.println("Tomorrow: " + tomorrow);
//
//            List<AppliedPolicy> policies = appliedPolicyRepository.findByNextPaymentDate(tomorrow);
//            System.out.println("Policies found: " + policies.size());
//
//            for (AppliedPolicy policy : policies) {
//                System.out.println("Processing policy: " + policy.getPolicyName() + " for user " + policy.getUserName());
//                Optional<User> userOptional = userRepository.findByUserName(policy.getUserName());
//                if (userOptional.isPresent()) {
//                    String email = userOptional.get().getEmail();
//                    System.out.println("Sending email to: " + email);
//                    sendEmail(email, "Payment Reminder", "Your next payment is due tomorrow.");
//                } else {
//                    System.out.println("User not found for policy: " + policy.getPolicyName());
//                }
//            }
//        } catch (Exception e) {
//            System.err.println("Error in sendPaymentReminderEmails: " + e.getMessage());
//        }
//    }
//
//    private void sendEmail(String to, String subject, String text) {
//        try {
//            System.out.println("hey here");
//            SimpleMailMessage message = new SimpleMailMessage();
//            message.setTo(to);
//            message.setSubject(subject);
//            message.setText(text);
//            mailSender.send(message);
//            System.out.println("Email sent successfully to " + to);
//        } catch (Exception e) {
//            System.err.println("Error sending email: " + e.getMessage());
//        }
//    }
//}




@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private AppliedPolicyRepository appliedPolicyRepository;

    @Autowired
    private UserRepository userRepository;


    //    @Scheduled(cron = "0 * * * * ?") // Every minute
    //@Scheduled(cron = "0 0 10 * * ?") // Every minute
    @Scheduled(cron = "0 0 10 * * ?")
    public void sendPaymentReminderEmails() {
        try {
            System.out.println("Scheduler triggered");
            java.util.Date today = new java.util.Date();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(today);
            calendar.add(Calendar.DAY_OF_YEAR, 1);
            java.sql.Date tomorrow = new java.sql.Date(calendar.getTimeInMillis());

            System.out.println("Today: " + today);
            System.out.println("Tomorrow: " + tomorrow);

            List<AppliedPolicy> policies = appliedPolicyRepository.findByNextPaymentDate(tomorrow);
            System.out.println("Policies found: " + policies.size());

            for (AppliedPolicy policy : policies) {
                System.out.println("Processing policy: " + policy.getPolicyName() + " for user " + policy.getUserName());
                Optional<User> userOptional = userRepository.findByUserName(policy.getUserName());
                if (userOptional.isPresent()) {
                    String email = userOptional.get().getEmail();
                    System.out.println("Sending email to: " + email);
                    sendEmail(email, "Payment Reminder", "Your next payment is due tomorrow.");
                } else {
                    System.out.println("User not found for policy: " + policy.getPolicyName());
                }
            }
        } catch (Exception e) {
            System.err.println("Error in sendPaymentReminderEmails: " + e.getMessage());
        }
    }

    private void sendEmail(String to, String subject, String text) {
        try {
            System.out.println("hey here");
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(to);
            message.setSubject(subject);
            message.setText(text);
            mailSender.send(message);
            System.out.println("Email sent successfully to " + to);
        } catch (Exception e) {
            System.err.println("Error sending email: " + e.getMessage());
        }
    }
}





