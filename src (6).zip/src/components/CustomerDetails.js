// import React, { useState } from 'react';
// import { useNavigate, useParams } from 'react-router-dom';
// import axios from 'axios';

// const CustomerDetails = () => {
//   const { policyId } = useParams();
//   const [customer, setCustomer] = useState({
//     customerName: '', occupation: '', city: '', state: '', country: '', zip: '',
//     mobileNumber: '', DOB1: '', nomineeName: '', nomineeOccupation: '',
//     nomineeAddress: '', nomineemobileNumber: '', nomineeDOB: ''
//   });
//   const navigate = useNavigate();

//   const handleChange = (e) => {
//     setCustomer({ ...customer, [e.target.name]: e.target.value });
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     axios.post('http://localhost:8080/api/customers', customer)
//       .then(response => {
//         navigate(`/customer/apply-policy/${policyId}`);
//       })
//       .catch(error => console.error(error));
//   };

//   return (
//     <div>
//       <h2>Customer Details</h2>
//       <form onSubmit={handleSubmit}>
        // <label>
        //   Customer Name:
        //   <input type="text" name="customerName" value={customer.customerName} onChange={handleChange} required />
        // </label>
        // <label>
        //   Occupation:
        //   <input type="text" name="occupation" value={customer.occupation} onChange={handleChange} required />
        // </label>
        // <label>
        //   City:
        //   <input type="text" name="city" value={customer.city} onChange={handleChange} required />
        // </label>
        // <label>
        //   State:
        //   <input type="text" name="state" value={customer.state} onChange={handleChange} required />
        // </label>
        // <label>
        //   Country:
        //   <input type="text" name="country" value={customer.country} onChange={handleChange} required />
        // </label>
        // <label>
        //   ZIP Code:
        //   <input type="number" name="zip" value={customer.zip} onChange={handleChange} required />
        // </label>
        // <label>
        //   Mobile Number:
        //   <input type="number" name="mobileNumber" value={customer.mobileNumber} onChange={handleChange} required />
        // </label>
        // <label>
        //   Date of Birth:
        //   <input type="date" name="DOB1" value={customer.DOB1} onChange={handleChange} required />
        // </label>
        // <label>
        //   Nominee Name:
        //   <input type="text" name="nomineeName" value={customer.nomineeName} onChange={handleChange} required />
        // </label>
        // <label>
        //   Nominee Occupation:
        //   <input type="text" name="nomineeOccupation" value={customer.nomineeOccupation} onChange={handleChange} required />
        // </label>
        // <label>
        //   Nominee Address:
        //   <input type="text" name="nomineeAddress" value={customer.nomineeAddress} onChange={handleChange} required />
        // </label>
        // <label>
        //   Nominee Mobile Number:
        //   <input type="number" name="nomineemobileNumber" value={customer.nomineemobileNumber} onChange={handleChange} required />
        // </label>
        // <label>
        //   Nominee Date of Birth:
        //   <input type="date" name="nomineeDOB" value={customer.nomineeDOB} onChange={handleChange} required />
        // </label>
//         <button type="submit">Next</button>
//       </form>
//     </div>
//   );
// };

// export default CustomerDetails;

//now
// import React, { useState } from 'react';
// import { useNavigate, useParams, useLocation } from 'react-router-dom';
// import axios from 'axios';

// const CustomerDetails = () => {
//   const { policyId } = useParams();
//   const location = useLocation();
//   const { policyName, planType } = location.state || {};
//   const [customer, setCustomer] = useState({
//     customerName: '', occupation: '', city: '', state: '', country: '', zip: '',
//     mobileNumber: '', DOB1: '', nomineeName: '', nomineeOccupation: '',
//     nomineeAddress: '', nomineemobileNumber: '', nomineeDOB: ''
//   });
//   const navigate = useNavigate();

//   const handleChange = (e) => {
//     setCustomer({ ...customer, [e.target.name]: e.target.value });
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     axios.post('http://localhost:8080/api/customers', customer)
//       .then(response => {
//         navigate(`/customer/apply-policy/${policyId}`, { state: { policyName, planType, customerName: customer.customerName } });
//       })
//       .catch(error => console.error(error));
//   };

//   return (
//     <div>
//       <h2>Customer Details</h2>
//       <form onSubmit={handleSubmit}>
//         {/* Form fields */}
//         <label>
//           Customer Name:
//           <input type="text" name="customerName" value={customer.customerName} onChange={handleChange} required />
//         </label>
//         <label>
//           Occupation:
//           <input type="text" name="occupation" value={customer.occupation} onChange={handleChange} required />
//         </label>
//         <label>
//           City:
//           <input type="text" name="city" value={customer.city} onChange={handleChange} required />
//         </label>
//         <label>
//           State:
//           <input type="text" name="state" value={customer.state} onChange={handleChange} required />
//         </label>
//         <label>
//           Country:
//           <input type="text" name="country" value={customer.country} onChange={handleChange} required />
//         </label>
//         <label>
//           ZIP Code:
//           <input type="number" name="zip" value={customer.zip} onChange={handleChange} required />
//         </label>
//         <label>
//           Mobile Number:
//           <input type="number" name="mobileNumber" value={customer.mobileNumber} onChange={handleChange} required />
//         </label>
//         <label>
//           Date of Birth:
//           <input type="date" name="DOB1" value={customer.DOB1} onChange={handleChange} required />
//         </label>
//         <label>
//           Nominee Name:
//           <input type="text" name="nomineeName" value={customer.nomineeName} onChange={handleChange} required />
//         </label>
//         <label>
//           Nominee Occupation:
//           <input type="text" name="nomineeOccupation" value={customer.nomineeOccupation} onChange={handleChange} required />
//         </label>
//         <label>
//           Nominee Address:
//           <input type="text" name="nomineeAddress" value={customer.nomineeAddress} onChange={handleChange} required />
//         </label>
//         <label>
//           Nominee Mobile Number:
//           <input type="number" name="nomineemobileNumber" value={customer.nomineemobileNumber} onChange={handleChange} required />
//         </label>
//         <label>
//           Nominee Date of Birth:
//           <input type="date" name="nomineeDOB" value={customer.nomineeDOB} onChange={handleChange} required />
//         </label>
//         <button type="submit">Next</button>
//       </form>
//     </div>
//   );
// };

// export default CustomerDetails;

// import React, { useState } from 'react';
// import { useNavigate, useParams, useLocation } from 'react-router-dom';
// import axios from 'axios';

// const CustomerDetails = () => {
//     const { policyId } = useParams();
//     const location = useLocation();
//     const { policyName, planType, userName } = location.state || {};
//     const [customer, setCustomer] = useState({
//         customerName: '', occupation: '', city: '', state: '', country: '', zip: '',
//         mobileNumber: '', DOB1: '', nomineeName: '', nomineeOccupation: '',
//         nomineeAddress: '', nomineemobileNumber: '', nomineeDOB: ''
//     });
//     const navigate = useNavigate();

//     const handleChange = (e) => {
//         setCustomer({ ...customer, [e.target.name]: e.target.value });
//     };

//     const handleSubmit = (e) => {
//         e.preventDefault();
//         const customerData = { ...customer, userName }; // Include userName in the data
//         axios.post('http://localhost:8080/api/customers', customerData)
//             .then(response => {
//                 navigate(`/customer/apply-policy/${policyId}`, { state: { policyName, planType, customerName: customer.customerName, userName } });
//             })
//             .catch(error => console.error(error));
//     };

//     return (
//         <div>
//             <h2>Customer Details</h2>
//             <form onSubmit={handleSubmit}>
//                 {/* Form fields */}
//                 <label>
//                     Customer Name:
//                     <input type="text" name="customerName" value={customer.customerName} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     Occupation:
//                     <input type="text" name="occupation" value={customer.occupation} onChange={handleChange} required />


//                 </label>
//                 <label>
//                     City:
//                     <input type="text" name="city" value={customer.city} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     State:
//                     <input type="text" name="state" value={customer.state} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     Country:
//                     <input type="text" name="country" value={customer.country} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     ZIP Code:
//                     <input type="number" name="zip" value={customer.zip} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     Mobile Number:
//                     <input type="number" name="mobileNumber" value={customer.mobileNumber} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     Date of Birth:
//                     <input type="date" name="DOB1" value={customer.DOB1} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     Nominee Name:
//                     <input type="text" name="nomineeName" value={customer.nomineeName} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     Nominee Occupation:
//                     <input type="text" name="nomineeOccupation" value={customer.nomineeOccupation} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     Nominee Address:
//                     <input type="text" name="nomineeAddress" value={customer.nomineeAddress} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     Nominee Mobile Number:
//                     <input type="number" name="nomineemobileNumber" value={customer.nomineemobileNumber} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     Nominee Date of Birth:
//                     <input type="date" name="nomineeDOB" value={customer.nomineeDOB} onChange={handleChange} required />
//                 </label>
//                 <button type="submit">Next</button>
//             </form>
//         </div>
//     );
// };

// export default CustomerDetails;


import React, { useState } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import axios from 'axios';

const CustomerDetails = () => {
    const { policyId } = useParams();
    const location = useLocation();
    const { policyName, planType, userName } = location.state || {};

    const [customer, setCustomer] = useState({
        customerName: '', occupation: '', city: '', state: '', country: '', zip: '',
        mobileNumber: '', DOB1: '', nomineeName: '', nomineeOccupation: '',
        nomineeAddress: '', nomineemobileNumber: '', nomineeDOB: ''
    });

    const [errors, setErrors] = useState({});
    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;

        let updatedErrors = { ...errors };
        
        if (name === 'DOB1' || name === 'nomineeDOB') {
            const age = calculateAge(value);
            if (age < 18) {
                updatedErrors[name] = 'Age should be greater than 18';
            } else if (new Date(value) > new Date()) {
                updatedErrors[name] = 'Date should not be in the future';
            } else {
                delete updatedErrors[name];
            }
        }

        setCustomer({ ...customer, [name]: value });
        setErrors(updatedErrors);
    };

    const calculateAge = (dob) => {
        const today = new Date();
        const birthDate = new Date(dob);
        let age = today.getFullYear() - birthDate.getFullYear();
        const monthDiff = today.getMonth() - birthDate.getMonth();
        if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
            age--;
        }
        return age;
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        if (Object.keys(errors).length > 0) {
            console.error('Please fix the errors before submitting.');
            return;
        }

        const customerData = { ...customer, userName };
        axios.post('http://localhost:8080/api/customers', customerData)
            .then(response => {
                navigate(`/customer/apply-policy/${policyId}`, { state: { policyName, planType, customerName: customer.customerName, userName } });
            })
            .catch(error => console.error(error));
    };

    return (
        <div>
            <h2>Customer Details</h2>
            <form onSubmit={handleSubmit}>
                <label>
                    Customer Name:
                    <input type="text" name="customerName" value={customer.customerName} onChange={handleChange} required />
                </label>
                <label>
                    Occupation:
                    <input type="text" name="occupation" value={customer.occupation} onChange={handleChange} required />
                </label>
                <label>
                    City:
                    <input type="text" name="city" value={customer.city} onChange={handleChange} required />
                </label>
                <label>
                    State:
                    <input type="text" name="state" value={customer.state} onChange={handleChange} required />
                </label>
                <label>
                    Country:
                    <input type="text" name="country" value={customer.country} onChange={handleChange} required />
                </label>
                <label>
                    ZIP Code:
                    <input type="number" name="zip" value={customer.zip} onChange={handleChange} required />
                </label>
                <label>
                    Mobile Number:
                    <input type="number" name="mobileNumber" value={customer.mobileNumber} onChange={handleChange} required />
                </label>
                <label>
                    Date of Birth:
                    <input type="date" name="DOB1" value={customer.DOB1} onChange={handleChange} required />
                    {errors.DOB1 && <span className="error">{errors.DOB1}</span>}
                </label>
                <label>
                    Nominee Name:
                    <input type="text" name="nomineeName" value={customer.nomineeName} onChange={handleChange} required />
                </label>
                <label>
                    Nominee Occupation:
                    <input type="text" name="nomineeOccupation" value={customer.nomineeOccupation} onChange={handleChange} required />
                </label>
                <label>
                    Nominee Address:
                    <input type="text" name="nomineeAddress" value={customer.nomineeAddress} onChange={handleChange} required />
                </label>
                <label>
                    Nominee Mobile Number:
                    <input type="number" name="nomineemobileNumber" value={customer.nomineemobileNumber} onChange={handleChange} required />
                </label>
                <label>
                    Nominee Date of Birth:
                    <input type="date" name="nomineeDOB" value={customer.nomineeDOB} onChange={handleChange} required />
                    {errors.nomineeDOB && <span className="error">{errors.nomineeDOB}</span>}
                </label>
                <button type="submit">Next</button>
            </form>
        </div>
    );
};

export default CustomerDetails;
