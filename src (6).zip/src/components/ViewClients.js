import React, { useEffect, useState } from 'react';
import axios from 'axios';

const ViewClients = () => {
    const [clients, setClients] = useState([]);

    useEffect(() => {
        fetchClients();
    }, []);

    const fetchClients = async () => {
        try {
            const response = await axios.get('/api/customers');
            setClients(response.data);
        } catch (error) {
            console.error('Error fetching clients', error);
        }
    };

    return (
        <div>
            <h2>View Clients</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Occupation</th>
                        <th>City</th>
                        <th>State</th>
                        <th>Country</th>
                        <th>ZIP</th>
                        <th>Mobile Number</th>
                        {/* <th>Date of Birth</th> */}
                        <th>Nominee Name</th>
                        <th>Nominee Occupation</th>
                        <th>Nominee Address</th>
                        <th>Nominee Mobile Number</th>
                        <th>Nominee Date of Birth</th>
                    </tr>
                </thead>
                <tbody>
                    {clients.map((client) => (
                        <tr key={client.customerId}>
                            <td>{client.customerId}</td>
                            <td>{client.customerName}</td>
                            <td>{client.occupation}</td>
                            <td>{client.city}</td>
                            <td>{client.state}</td>
                            <td>{client.country}</td>
                            <td>{client.zip}</td>
                            <td>{client.mobileNumber}</td>
                            {/* <td>{client.DOB1}</td> */}
                            <td>{client.nomineeName}</td>
                            <td>{client.nomineeOccupation}</td>
                            <td>{client.nomineeAddress}</td>
                            <td>{client.nomineemobileNumber}</td>
                            <td>{client.nomineeDOB}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ViewClients;
