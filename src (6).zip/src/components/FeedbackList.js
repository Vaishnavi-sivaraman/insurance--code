import React, { useEffect, useState } from 'react';
import axios from 'axios';

function FeedbackList() {
  const [feedbacks, setFeedbacks] = useState([]);

  useEffect(() => {
    fetchFeedbacks();
  }, []);

  const fetchFeedbacks = async () => {
    try {
      const response = await axios.get('/api/feedback');
      setFeedbacks(response.data);
    } catch (error) {
      console.error('Error fetching feedbacks', error);
    }
  };

  const deleteFeedback = async (id) => {
    try {
      await axios.delete(`/api/feedback/${id}`);
      fetchFeedbacks();
    } catch (error) {
      console.error('Error deleting feedback', error);
    }
  };

  return (
    <div>
      <h1>Feedback List</h1>
      <table>
        <thead>
          <tr>
            <th>Customer Name</th>
            <th>Comments</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {feedbacks.map((feedback) => (
            <tr key={feedback.feedbackId}>
              <td>{feedback.customerName}</td>
              <td>{feedback.comments}</td>
              <td>
                <button onClick={() => deleteFeedback(feedback.feedbackId)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default FeedbackList;
