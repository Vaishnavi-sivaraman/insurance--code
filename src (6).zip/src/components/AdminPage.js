import React from 'react';
import { Link } from 'react-router-dom';

const AdminPage = () => (
    <div>
        <nav>
            <ul>
                <li><Link to="/admin/insurance-plans">Insurance Plans</Link></li>
                <li><Link to="/admin/view-clients">View Clients</Link></li>
                <li><Link to="/admin/approved-insurance">Approved Insurance</Link></li>
                <li><Link to="/admin/view-feedback">View Feedback</Link></li>
                <li><Link to="/admin/pending-approvals">Pending Approvals</Link></li>
            </ul>
        </nav>
    </div>
);

export default AdminPage;
