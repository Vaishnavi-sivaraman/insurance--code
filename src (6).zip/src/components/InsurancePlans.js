// import React, { useEffect, useState } from 'react';
// import axios from 'axios';

// axios.defaults.baseURL = 'http://localhost:8080';

// const InsurancePlans = () => {
//     const [plans, setPlans] = useState([]);
//     const [selectedId, setSelectedId] = useState(null);
//     const [formData, setFormData] = useState({
//         policyName: '',
//         planType: '',
//         description: '',
//         period: ''
//     });

//     // useEffect(() => {
//     //     fetchPlans();
//     // }, []);

//     const fetchPlans = async () => {
//         try {
//             const response = await axios.get('/api/policies');
//             setPlans(response.data);
//         } catch (error) {
//             console.error('Error fetching insurance plans', error);
//         }
//     };

//     const handleInputChange = (e) => {
//         const { name, value } = e.target;
//         setFormData({ ...formData, [name]: value });
//     };

//     const handleAdd = async () => {
//         try {
//             const response = await axios.post('/api/policies', formData);
//             setPlans([...plans, response.data]);
//             setFormData({
//                 policyName: '',
//                 planType: '',
//                 description: '',
//                 period: ''
//             });
//         } catch (error) {
//             console.error('Error adding insurance plan', error);
//         }
//     };

//     const handleDelete = async (id) => {
//         try {
//             await axios.delete(`/api/policies/${id}`);
//             setPlans(plans.filter(plan => plan.policyId !== id));
//         } catch (error) {
//             console.error('Error deleting insurance plan', error);
//         }
//     };

//     const handleUpdate = async (id) => {
//         try {
//             const response = await axios.put(`/api/policies/${id}`, formData);
//             setPlans(plans.map(plan => (plan.policyId === id ? response.data : plan)));
//             setFormData({
//                 policyName: '',
//                 planType: '',
//                 description: '',
//                 period: ''
//             });
//             setSelectedId(null);
//         } catch (error) {
//             console.error('Error updating insurance plan', error);
//         }
//     };

//     return (
//         <div>
//             <h2>Insurance Plans</h2>
//             <div>
//                 <input
//                     type="text"
//                     name="policyName"
//                     placeholder="Policy Name"
//                     value={formData.policyName}
//                     onChange={handleInputChange}
//                 />
//                 <input
//                     type="text"
//                     name="planType"
//                     placeholder="Plan Type"
//                     value={formData.planType}
//                     onChange={handleInputChange}
//                 />
//                 <input
//                     type="text"
//                     name="description"
//                     placeholder="Description"
//                     value={formData.description}
//                     onChange={handleInputChange}
//                 />
//                 <input
//                     type="text"
//                     name="period"
//                     placeholder="Period"
//                     value={formData.period}
//                     onChange={handleInputChange}
//                 />
//                 <button onClick={handleAdd}>Add Insurance</button>
//                 {selectedId && (
//                     <button onClick={() => handleUpdate(selectedId)}>Update Insurance</button>
//                 )}
//             </div>
//             <button onClick={fetchPlans}>View Insurance</button>
            
//             <table>
//                 <thead>
//                     <tr>
//                         <th>ID</th>
//                         <th>Name</th>
//                         <th>Type</th>
//                         <th>Description</th>
//                         <th>Period</th>
//                         <th>Actions</th>
//                     </tr>
//                 </thead>
//                 <tbody>
//                     {plans.map((plan) => (
//                         <tr key={plan.policyId}>
//                             <td>{plan.policyId}</td>
//                             <td>{plan.policyName}</td>
//                             <td>{plan.planType}</td>
//                             <td>{plan.description}</td>
//                             <td>{plan.period}</td>
//                             <td>
//                                 <button onClick={() => setSelectedId(plan.policyId)}>Edit</button>
//                                 <button onClick={() => handleDelete(plan.policyId)}>Delete</button>
//                             </td>
//                         </tr>
//                     ))}
//                 </tbody>
//             </table> 
                
//         </div>
//     );
// };

// export default InsurancePlans;


import React, { useState } from 'react';
import axios from 'axios';

axios.defaults.baseURL = 'http://localhost:8080';

const InsurancePlans = () => {
    const [plans, setPlans] = useState([]);
    const [selectedId, setSelectedId] = useState(null);
    const [formData, setFormData] = useState({
        policyName: '',
        planType: '',
        description: '',
        period: ''
    });
    const [showTable, setShowTable] = useState(false);

    const fetchPlans = async () => {
        try {
            const response = await axios.get('/api/policies');
            setPlans(response.data);
            setShowTable(true); // Show the table when data is fetched
        } catch (error) {
            console.error('Error fetching insurance plans', error);
        }
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleAdd = async () => {
        try {
            const response = await axios.post('/api/policies', formData);
            setPlans([...plans, response.data]);
            setFormData({
                policyName: '',
                planType: '',
                description: '',
                period: ''
            });
        } catch (error) {
            console.error('Error adding insurance plan', error);
        }
    };

    const handleDelete = async (id) => {
        try {
            await axios.delete(`/api/policies/${id}`);
            setPlans(plans.filter(plan => plan.policyId !== id));
        } catch (error) {
            console.error('Error deleting insurance plan', error);
        }
    };

    const handleUpdate = async (id) => {
        try {
            const response = await axios.put(`/api/policies/${id}`, formData);
            setPlans(plans.map(plan => (plan.policyId === id ? response.data : plan)));
            setFormData({
                policyName: '',
                planType: '',
                description: '',
                period: ''
            });
            setSelectedId(null);
        } catch (error) {
            console.error('Error updating insurance plan', error);
        }
    };

    return (
        <div>
            <h2>Insurance Plans</h2>
            <div>
                <input
                    type="text"
                    name="policyName"
                    placeholder="Policy Name"
                    value={formData.policyName}
                    onChange={handleInputChange}
                />
                <input
                    type="text"
                    name="planType"
                    placeholder="Plan Type"
                    value={formData.planType}
                    onChange={handleInputChange}
                />
                <input
                    type="text"
                    name="description"
                    placeholder="Description"
                    value={formData.description}
                    onChange={handleInputChange}
                />
                <input
                    type="text"
                    name="period"
                    placeholder="Period"
                    value={formData.period}
                    onChange={handleInputChange}
                />
                <button onClick={handleAdd}>Add Insurance</button>
                {selectedId && (
                    <button onClick={() => handleUpdate(selectedId)}>Update Insurance</button>
                )}
            </div>
            <button onClick={fetchPlans}>View Insurance</button>
            {showTable && (
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Type</th>
                            <th>Description</th>
                            <th>Period</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {plans.map((plan) => (
                            <tr key={plan.policyId}>
                                <td>{plan.policyId}</td>
                                <td>{plan.policyName}</td>
                                <td>{plan.planType}</td>
                                <td>{plan.description}</td>
                                <td>{plan.period}</td>
                                <td>
                                    <button onClick={() => setSelectedId(plan.policyId)}>Edit</button>
                                    <button onClick={() => handleDelete(plan.policyId)}>Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
    );
};

export default InsurancePlans;
