package com.example.insurance.model;
////
////import com.fasterxml.jackson.annotation.JsonFormat;
////import jakarta.persistence.*;
////import lombok.AllArgsConstructor;
////import lombok.Data;
////import lombok.NoArgsConstructor;
////
////import java.util.Date;
////
////@Entity
////@Table(name = "appliedPolicy")
////@Data
////@AllArgsConstructor
////@NoArgsConstructor
////public class AppliedPolicy {
////
////    @Id
////    @GeneratedValue(strategy = GenerationType.IDENTITY)
////    private Long appliedPolicyId;
////
////    private String policyName;
////    private String planType;
////    private String customerName;
////    private int term;
////    private int period;
////    @JsonFormat(pattern = "yyyy-MM-dd")
////    private Date currentDate;
////    @JsonFormat(pattern = "yyyy-MM-dd")
////    private Date nextPaymentDate;
////    private double termAmount;
////    private long coverageAmount;
////    private String status;
////
////    @Lob
////    private byte[] incomeCertificate;
////
////    @Lob
////    private byte[] selfCancelledCheque;
////
////    @Lob
////    private byte[] communicationAddressProof;
////
////    @Lob
////    private byte[] birthCertificate;
////
////    @Lob
////    private byte[] photo;
////
////    @Lob
////    private byte[] signature;
////
////    // Getters and Setters
////    // ...
////}
//package com.example.insurance.model;
//
//import com.fasterxml.jackson.annotation.JsonFormat;
//import jakarta.persistence.*;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
////import javax.persistence.*;
//import java.util.Date;
//
//@Entity
//@Table(name = "appliedPolicy")
//@Data
//@AllArgsConstructor
//@NoArgsConstructor
//public class AppliedPolicy {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long appliedPolicyId;
//
//    private String policyName;
//    private String planType;
//    private String customerName;
//    private int term;
//    private int period;
//    @JsonFormat(pattern = "yyyy-MM-dd")
//    private Date currentDate;
//    @JsonFormat(pattern = "yyyy-MM-dd")
//    private Date nextPaymentDate;
//    private long coverageAmount;
//    private long termAmount;
//    private String status;
//
//    @Lob
//    private String incomeCertificate;
//
//    @Lob
//    private String selfCancelledCheque;
//
//    @Lob
//    private String communicationAddressProof;
//
//    @Lob
//    private String birthCertificate;
//
//    @Lob
//    private String photo;
//
//    @Lob
//    private String signature;
//
////    private Date currentDate;
////    private Date nextPaymentDate;
//}
//

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


import java.util.Date;

@Entity
@Table(name = "appliedPolicy")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AppliedPolicy {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long appliedPolicyId;

    private String policyName;
    private String planType;
    private String customerName;
    private String userName;
    private int term;
    private int period;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date currentDate;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date nextPaymentDate;
    private long coverageAmount;
    private long termAmount;
    private String status;

    @Lob
    private String incomeCertificate;

    @Lob
    private String selfCancelledCheque;

    @Lob
    private String communicationAddressProof;

    @Lob
    private String birthCertificate;

    @Lob
    private String photo;

    @Lob
    private String signature;
}

