// import React, { useState } from 'react';
// import { useNavigate, useParams } from 'react-router-dom';
// import axios from 'axios';

// const ApplyPolicyDetails = () => {
//   const { policyId } = useParams();
//   const [policyDetails, setPolicyDetails] = useState({
//     policyName: '', planType: '', customerName: '', term: 0, period: 0,
//     coverageAmount: 0
//   });
//   const navigate = useNavigate();

//   const handleChange = (e) => {
//     setPolicyDetails({ ...policyDetails, [e.target.name]: e.target.value });
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     axios.post('http://localhost:8080/api/appliedPolicies', policyDetails)
//       .then(response => {
//         navigate(`/customer/upload-documents/${policyId}`);
//       })
//       .catch(error => console.error(error));
//   };

//   return (
//     <div>
//       <h2>Policy Application Details</h2>
//       <form onSubmit={handleSubmit}>
        // <label>
        //   Policy Name:
        //   <input type="text" name="policyName" value={policyDetails.policyName} onChange={handleChange} required />
        // </label>
        // <label>
        //   Plan Type:
        //   <input type="text" name="planType" value={policyDetails.planType} onChange={handleChange} required />
        // </label>
        // <label>
        //   Customer Name:
        //   <input type="text" name="customerName" value={policyDetails.customerName} onChange={handleChange} required />
        // </label>
        // <label>
        //   Term (months):
        //   <input type="number" name="term" value={policyDetails.term} onChange={handleChange} required />
        // </label>
        // <label>
        //   Period (years):
        //   <input type="number" name="period" value={policyDetails.period} onChange={handleChange} required />
        // </label>
        // <label>
        //   Coverage Amount:
        //   <input type="number" name="coverageAmount" value={policyDetails.coverageAmount} onChange={handleChange} required />
        // </label>
//         <button type="submit">Next</button>
//       </form>
//     </div>
//   );
// };

// export default ApplyPolicyDetails;

//now
// import React, { useState } from 'react';
// import { useNavigate, useParams, useLocation } from 'react-router-dom';
// import axios from 'axios';

// const ApplyPolicyDetails = () => {
//   const { policyId } = useParams();
//   const location = useLocation();
//   const { policyName, planType, customerName } = location.state || {};

//   const [policyDetails, setPolicyDetails] = useState({
//     policyName: policyName || '',
//     planType: planType || '',
//     customerName: customerName || '',
//     term: 0,
//     period: 0,
//     coverageAmount: 0
//   });

//   const navigate = useNavigate();

//   const handleChange = (e) => {
//     setPolicyDetails({ ...policyDetails, [e.target.name]: e.target.value });
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     const formData = new FormData();
//     for (const [key, value] of Object.entries(policyDetails)) {
//       formData.append(key, value);
//     }

//     axios.post('http://localhost:8080/api/appliedPolicies', formData, {
//       headers: {
//         'Content-Type': 'multipart/form-data'
//       }
//     })
//       .then(response => {
//         navigate(`/customer/upload-documents/${policyId}`);
//       })
//       .catch(error => console.error(error));
//   };

//   return (
//     <div>
//       <h2>Policy Application Details</h2>
//       <form onSubmit={handleSubmit}>
//         <label>
//           Policy Name:
//           <input type="text" name="policyName" value={policyDetails.policyName} onChange={handleChange} required />
//         </label>
//         <label>
//           Plan Type:
//           <input type="text" name="planType" value={policyDetails.planType} onChange={handleChange} required />
//         </label>
//         <label>
//           Customer Name:
//           <input type="text" name="customerName" value={policyDetails.customerName} onChange={handleChange} required />
//         </label>
//         <label>
//           Term (months):
//           <input type="number" name="term" value={policyDetails.term} onChange={handleChange} required />
//         </label>
//         <label>
//           Period (years):
//           <input type="number" name="period" value={policyDetails.period} onChange={handleChange} required />
//         </label>
//         <label>
//           Coverage Amount:
//           <input type="number" name="coverageAmount" value={policyDetails.coverageAmount} onChange={handleChange} required />
//         </label>
//         <button type="submit">Next</button>
//       </form>
//     </div>
//   );
// };

// export default ApplyPolicyDetails;


// import React, { useState } from 'react';
// import { useNavigate, useParams, useLocation } from 'react-router-dom';
// import axios from 'axios';

// const ApplyPolicyDetails = () => {
//     const { policyId } = useParams();
//     const location = useLocation();
//     const { policyName, planType, customerName, userName } = location.state || {};

//     const [policyDetails, setPolicyDetails] = useState({
//         policyName: policyName || '',
//         planType: planType || '',
//         customerName: customerName || '',
//         userName: userName || '',
//         term: 0,
//         period: 0,
//         coverageAmount: 0
//     });

//     const navigate = useNavigate();

//     const handleChange = (e) => {
//         setPolicyDetails({ ...policyDetails, [e.target.name]: e.target.value });
//     };

//     const handleSubmit = (e) => {
//         e.preventDefault();
//         const formData = new FormData();
//         for (const [key, value] of Object.entries(policyDetails)) {
//             formData.append(key, value);
//         }

//         axios.post('http://localhost:8080/api/appliedPolicies', formData, {
//             headers: {
//                 'Content-Type': 'multipart/form-data'
//             }
//         })
//             .then(response => {
//                 navigate(`/customer/upload-documents/${policyId}`);
//             })
//             .catch(error => console.error(error));
//     };

//     return (
//         <div>
//             <h2>Policy Application Details</h2>
//             <form onSubmit={handleSubmit}>
//                 <label>
//                     Policy Name:
//                     <input type="text" name="policyName" value={policyDetails.policyName} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     Plan Type:
//                     <input type="text" name="planType" value={policyDetails.planType} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     Customer Name:
//                     <input type="text" name="customerName" value={policyDetails.customerName} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     User Name:
//                     <input type="text" name="userName" value={policyDetails.userName} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     Term (months):
//                     <input type="number" name="term" value={policyDetails.term} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     Period (years):
//                     <input type="number" name="period" value={policyDetails.period} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     Coverage Amount:
//                     <input type="number" name="coverageAmount" value={policyDetails.coverageAmount} onChange={handleChange} required />
//                 </label>
//                 <button type="submit">Next</button>
//             </form>
//         </div>
//     );
// };

// export default ApplyPolicyDetails;

// import React, { useState } from 'react';
// import { useNavigate, useParams, useLocation } from 'react-router-dom';
// import axios from 'axios';

// const ApplyPolicyDetails = () => {
//     const { policyId } = useParams();
//     const location = useLocation();
//     const { policyName, planType, customerName, userName } = location.state || {};

//     const [policyDetails, setPolicyDetails] = useState({
//         policyName: policyName || '',
//         planType: planType || '',
//         customerName: customerName || '',
//         userName: userName || '',
//         term: 0,
//         period: 0,
//         coverageAmount: 0
//     });

//     const navigate = useNavigate();

//     const handleChange = (e) => {
//         setPolicyDetails({ ...policyDetails, [e.target.name]: e.target.value });
//     };

//     const handleSubmit = (e) => {
//         e.preventDefault();
//         const formData = new FormData();
//         for (const [key, value] of Object.entries(policyDetails)) {
//             formData.append(key, value);
//         }

//         axios.post('http://localhost:8080/api/appliedPolicies', formData, {
//             headers: {
//                 'Content-Type': 'multipart/form-data'
//             }
//         })
//         .then(response => {
//             navigate(`/customer/upload-documents/${policyId}`, { state: { planType } });
//         })
//         .catch(error => console.error(error));
//     };

//     return (
//         <div>
//             <h2>Policy Application Details</h2>
//             <form onSubmit={handleSubmit}>
//                 <label>
//                     Policy Name:
//                     <input type="text" name="policyName" value={policyDetails.policyName} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     Plan Type:
//                     <input type="text" name="planType" value={policyDetails.planType} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     Customer Name:
//                     <input type="text" name="customerName" value={policyDetails.customerName} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     User Name:
//                     <input type="text" name="userName" value={policyDetails.userName} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     Term (months):
//                     <input type="number" name="term" value={policyDetails.term} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     Period (years):
//                     <input type="number" name="period" value={policyDetails.period} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     Coverage Amount:
//                     <input type="number" name="coverageAmount" value={policyDetails.coverageAmount} onChange={handleChange} required />
//                 </label>
//                 <button type="submit">Next</button>
//             </form>
//         </div>
//     );
// };

// export default ApplyPolicyDetails;

// import React, { useState } from 'react';
// import { useNavigate, useParams, useLocation } from 'react-router-dom';
// import axios from 'axios';

// const ApplyPolicyDetails = () => {
//     const { policyId } = useParams();
//     const location = useLocation();
//     const { policyName, planType, customerName, userName } = location.state || {};

//     const [policyDetails, setPolicyDetails] = useState({
//         policyName: policyName || '',
//         planType: planType || '',
//         customerName: customerName || '',
//         userName: userName || '',
//         term: 6,
//         period: 5,
//         coverageAmount: 10000
//     });

//     const [errors, setErrors] = useState({});
//     const navigate = useNavigate();

//     const handleChange = (e) => {
//         const { name, value } = e.target;

//         let updatedErrors = { ...errors };

//         if (name === 'coverageAmount') {
//             if (value < 10000 || value > 10000000) {
//                 updatedErrors[name] = 'Coverage amount should be between 10,000 and 10,000,000';
//             } else {
//                 delete updatedErrors[name];
//             }
//         }

//         setPolicyDetails({ ...policyDetails, [name]: value });
//         setErrors(updatedErrors);
//     };

//     const handleSubmit = (e) => {
//         e.preventDefault();

//         if (Object.keys(errors).length > 0) {
//             console.error('Please fix the errors before submitting.');
//             return;
//         }

//         const formData = new FormData();
//         for (const [key, value] of Object.entries(policyDetails)) {
//             formData.append(key, value);
//         }

//         axios.post('http://localhost:8080/api/appliedPolicies', formData, {
//             headers: {
//                 'Content-Type': 'multipart/form-data'
//             }
//         })
//         .then(response => {
//             navigate(`/customer/upload-documents/${policyId}`, { state: { planType } });
//         })
//         .catch(error => console.error(error));
//     };

//     return (
//         <div>
//             <h2>Policy Application Details</h2>
//             <form onSubmit={handleSubmit}>
//                 <label>
//                     Policy Name:
//                     <input type="text" name="policyName" value={policyDetails.policyName} disabled />
//                 </label>
//                 <label>
//                     Plan Type:
//                     <input type="text" name="planType" value={policyDetails.planType} disabled />
//                 </label>
//                 <label>
//                     Customer Name:
//                     <input type="text" name="customerName" value={policyDetails.customerName} disabled />
//                 </label>
//                 <label>
//                     User Name:
//                     <input type="text" name="userName" value={policyDetails.userName} disabled />
//                 </label>
//                 <label>
//                     Term (months):
//                     <select name="term" value={policyDetails.term} onChange={handleChange} required>
//                         <option value="6">6</option>
//                         <option value="12">12</option>
//                     </select>
//                 </label>
//                 <label>
//                     Period (years):
//                     <select name="period" value={policyDetails.period} onChange={handleChange} required>
//                         <option value="5">5</option>
//                         <option value="12">10</option>
//                     </select>
//                 </label>
//                 <label>
//                     Coverage Amount:
//                     <input type="number" name="coverageAmount" placeholder="coverage amount" value={policyDetails.coverageAmount} onChange={handleChange} required />
//                     {errors.coverageAmount && <span className="error">{errors.coverageAmount}</span>}
//                 </label>
//                 <button type="submit">Next</button>
//             </form>
//         </div>
//     );
// };

// export default ApplyPolicyDetails;

import React, { useState } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import axios from 'axios';

const ApplyPolicyDetails = () => {
    const { policyId } = useParams();
    const location = useLocation();
    const { policyName, planType, customerName, userName } = location.state || {};

    const [policyDetails, setPolicyDetails] = useState({
        policyName: policyName || '',
        planType: planType || '',
        customerName: customerName || '',
        userName: userName || '',
        term: 6,
        period: 5,
        coverageAmount: ''
    });

    const [errors, setErrors] = useState({});
    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;

        let updatedErrors = { ...errors };

        if (name === 'coverageAmount') {
            if (value < 10000 || value > 10000000) {
                updatedErrors[name] = 'Coverage amount should be between 10,000 and 10,000,000';
            } else {
                delete updatedErrors[name];
            }
        }

        setPolicyDetails({ ...policyDetails, [name]: value });
        setErrors(updatedErrors);
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        if (Object.keys(errors).length > 0) {
            console.error('Please fix the errors before submitting.');
            return;
        }

        const formData = new FormData();
        for (const [key, value] of Object.entries(policyDetails)) {
            formData.append(key, value);
        }

        axios.post('http://localhost:8080/api/appliedPolicies', formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        })
        .then(response => {
            navigate(`/customer/upload-documents/${policyId}`, { state: { planType } });
        })
        .catch(error => console.error(error));
    };

    return (
        <div>
            <h2>Policy Application Details</h2>
            <form onSubmit={handleSubmit}>
                <label>
                    Policy Name:
                    <input type="text" name="policyName" value={policyDetails.policyName} disabled />
                </label>
                <label>
                    Plan Type:
                    <input type="text" name="planType" value={policyDetails.planType} disabled />
                </label>
                <label>
                    Customer Name:
                    <input type="text" name="customerName" value={policyDetails.customerName} disabled />
                </label>
                <label>
                    User Name:
                    <input type="text" name="userName" value={policyDetails.userName} disabled />
                </label>
                <label>
                    Term (months):
                    <select name="term" value={policyDetails.term} onChange={handleChange} required>
                        <option value="6">6</option>
                        <option value="12">12</option>
                    </select>
                </label>
                <label>
                    Period (years):
                    <select name="period" value={policyDetails.period} onChange={handleChange} required>
                        <option value="5">5</option>
                        <option value="12">12</option>
                    </select>
                </label>
                <label>
                    Coverage Amount:
                    <input
                        type="number"
                        name="coverageAmount"
                        value={policyDetails.coverageAmount}
                        onChange={handleChange}
                        placeholder="Enter coverage amount"
                        required
                    />
                    {errors.coverageAmount && <span className="error">{errors.coverageAmount}</span>}
                </label>
                <button type="submit">Next</button>
            </form>
        </div>
    );
};

export default ApplyPolicyDetails;



