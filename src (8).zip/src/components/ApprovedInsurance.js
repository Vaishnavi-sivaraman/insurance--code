// import React, { useEffect, useState } from 'react';
// import axios from 'axios';

// const ApprovedInsurance = () => {
//     const [clients, setClients] = useState([]);

//     useEffect(() => {
//         fetchApprovedClients();
//     }, []);

//     const fetchApprovedClients = async () => {
//         try {
//             const response = await axios.get('/api/appliedPolicies/approved');
//             setClients(response.data);
//         } catch (error) {
//             console.error('Error fetching approved clients', error);
//         }
//     };

//     return (
//         <div>
//             <h2>Approved Clients</h2>
//             <table>
//                 <thead>
//                     <tr>
//                         <th>ID</th>
//                         <th>Policy Name</th>
//                         <th>Plan Type</th>
//                         <th>Customer Name</th>
//                         <th>Term</th>
//                         <th>Period</th>
//                         <th>Current Date</th>
//                         <th>Next Payment Date</th>
//                         <th>Term Amount</th>
//                         <th>Coverage Amount</th>
//                         <th>Status</th>
//                     </tr>
//                 </thead>
//                 <tbody>
//                     {clients.map((client) => (
//                         <tr key={client.appliedPolicyId}>
//                             <td>{client.appliedPolicyId}</td>
//                             <td>{client.policyName}</td>
//                             <td>{client.planType}</td>
//                             <td>{client.customerName}</td>
//                             <td>{client.term}</td>
//                             <td>{client.period}</td>
//                             <td>{client.currentDate}</td>
//                             <td>{client.nextPaymentDate}</td>
//                             <td>{client.termAmount}</td>
//                             <td>{client.coverageAmount}</td>
//                             <td>{client.status}</td>
//                         </tr>
//                     ))}
//                 </tbody>
//             </table>
//         </div>
//     );
// };

// export default ApprovedInsurance;

import React, { useEffect, useState } from 'react';
import axios from 'axios';

const ApprovedInsurance = () => {
  const [clients, setClients] = useState([]);
  const [filteredClients, setFilteredClients] = useState([]);
  const [selectedPlanType, setSelectedPlanType] = useState('all');

  useEffect(() => {
    fetchApprovedClients();
  }, []);

  useEffect(() => {
    filterClientsByPlanType(selectedPlanType);
  }, [clients, selectedPlanType]);

  const fetchApprovedClients = async () => {
    try {
      const response = await axios.get('/api/appliedPolicies/approved');
      setClients(response.data);
      setFilteredClients(response.data); // Initially display all clients
    } catch (error) {
      console.error('Error fetching approved clients', error);
    }
  };

  const filterClientsByPlanType = (planType) => {
    if (planType === 'all') {
      setFilteredClients(clients);
    } else {
      setFilteredClients(clients.filter(client => client.planType === planType));
    }
  };

  const handleButtonClick = (planType) => {
    setSelectedPlanType(planType);
  };

  return (
    <div>
      <h2>Approved Clients</h2>
      <div>
        <button onClick={() => handleButtonClick('all')}>All Clients</button>
        <button onClick={() => handleButtonClick('life')}>Life</button>
        <button onClick={() => handleButtonClick('health')}>Health</button>
        <button onClick={() => handleButtonClick('home')}>Home</button>
        <button onClick={() => handleButtonClick('vehicle')}>Vehicle</button>
      </div>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Policy Name</th>
            <th>Plan Type</th>
            <th>Customer Name</th>
            <th>Term</th>
            <th>Period</th>
            <th>Current Date</th>
            <th>Next Payment Date</th>
            <th>Term Amount</th>
            <th>Coverage Amount</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {filteredClients.map((client) => (
            <tr key={client.appliedPolicyId}>
              <td>{client.appliedPolicyId}</td>
              <td>{client.policyName}</td>
              <td>{client.planType}</td>
              <td>{client.customerName}</td>
              <td>{client.term}</td>
              <td>{client.period}</td>
              <td>{client.currentDate}</td>
              <td>{client.nextPaymentDate}</td>
              <td>{client.termAmount}</td>
              <td>{client.coverageAmount}</td>
              <td>{client.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ApprovedInsurance;
