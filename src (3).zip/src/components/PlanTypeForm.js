import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate, useLocation } from 'react-router-dom';

const PlanTypeForm = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const { planType = '' } = location.state || {};
    console.log(planType);
    const [formData, setFormData] = useState({
        // Initialize all possible fields here
        annualIncome: '',
        healthHistory: '',
        smokingStatus: '',
        hobbiesLifestyle: '',
        medicalExamDetails: '',
        propertyAddress: '',
        yearBuilt: '',
        residenceType: '',
        squareFootage: '',
        securitySystems: '',
        heightWeight: '',
        existingConditions: '',
        primaryPhysician: '',
        medications: '',
        hospitalPreferences: '',
        vin: '',
        currentMileage: '',
        previousClaims: '',
        usageType: '',
        usageFrequency: '',
    });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(formData);
        console.log.apply(planType);
        axios.post(`http://localhost:8080/api/${planType}-insurance `, formData)
            .then(response => {
                alert('Details submitted successfully');
                navigate('/customer/success-page'); // Navigate to a success page or dashboard
            })
            .catch(error => console.error(error));
    };

    const renderFormFields = () => {
        switch (planType) {
            case 'life':
                return (
                    <>
                        <label>
                            Annual Income:
                            <input type="number" name="annualIncome" value={formData.annualIncome} onChange={handleChange} required />
                        </label>
                        <label>
                            Health History:
                            <textarea name="healthHistory" value={formData.healthHistory} onChange={handleChange} required />
                        </label>
                        <label>
                            Smoking Status:
                            <select name="smokingStatus" value={formData.smokingStatus} onChange={handleChange} required>
                                <option value="non-smoker">Non-Smoker</option>
                                <option value="smoker">Smoker</option>
                            </select>
                        </label>
                        <label>
                            Hobbies and Lifestyle:
                            <textarea name="hobbiesLifestyle" value={formData.hobbiesLifestyle} onChange={handleChange} required />
                        </label>
                        <label>
                            Medical Exam Details:
                            <textarea name="medicalExamDetails" value={formData.medicalExamDetails} onChange={handleChange} required />
                        </label>
                    </>
                );
            case 'home':
                return (
                    <>
                        <label>
                            Property Address:
                            <input type="text" name="propertyAddress" value={formData.propertyAddress} onChange={handleChange} required />
                        </label>
                        <label>
                            Year Built:
                            <input type="number" name="yearBuilt" value={formData.yearBuilt} onChange={handleChange} required />
                        </label>
                        <label>
                            Type of Residence:
                            <select name="residenceType" value={formData.residenceType} onChange={handleChange} required>
                                <option value="single-family">Single-family</option>
                                <option value="condo">Condo</option>
                                <option value="townhouse">Townhouse</option>
                                <option value="multi-family">Multi-family</option>
                            </select>
                        </label>
                        <label>
                            Square Footage:
                            <input type="number" name="squareFootage" value

={formData.squareFootage} onChange={handleChange} required />
                        </label>
                        <label>
                            Security Systems:
                            <select name="securitySystems" value={formData.securitySystems} onChange={handleChange} required>
                                <option value="yes">Yes</option>
                                <option value="no">No</option>
                            </select>
                        </label>
                    </>
                );
            case 'health':
                return (
                    <>
                        <label>
                            Height and Weight:
                            <input type="text" name="heightWeight" value={formData.heightWeight} onChange={handleChange} required />
                        </label>
                        <label>
                            Existing Medical Conditions:
                            <textarea name="existingConditions" value={formData.existingConditions} onChange={handleChange} required />
                        </label>
                        <label>
                            Primary Care Physician:
                            <input type="text" name="primaryPhysician" value={formData.primaryPhysician} onChange={handleChange} required />
                        </label>
                        <label>
                            Medications:
                            <textarea name="medications" value={formData.medications} onChange={handleChange} required />
                        </label>
                        <label>
                            Hospital Preferences:
                            <textarea name="hospitalPreferences" value={formData.hospitalPreferences} onChange={handleChange} required />
                        </label>
                    </>
                );
            case 'vehicle':
                return (
                    <>
                        <label>
                            Vehicle Identification Number (VIN):
                            <input type="text" name="vin" value={formData.vin} onChange={handleChange} required />
                        </label>
                        <label>
                            Current Mileage:
                            <input type="number" name="currentMileage" value={formData.currentMileage} onChange={handleChange} required />
                        </label>
                        <label>
                            Previous Claims:
                            <textarea name="previousClaims" value={formData.previousClaims} onChange={handleChange} required />
                        </label>
                        <label>
                            Usage Type:
                            <select name="usageType" value={formData.usageType} onChange={handleChange} required>
                                <option value="personal">Personal</option>
                                <option value="commercial">Commercial</option>
                            </select>
                        </label>
                        <label>
                            Vehicle Usage Frequency:
                            <select name="usageFrequency" value={formData.usageFrequency} onChange={handleChange} required>
                                <option value="daily">Daily</option>
                                <option value="weekly">Weekly</option>
                                <option value="occasional">Occasional</option>
                            </select>
                        </label>
                    </>
                );
            default:
                return <p>Invalid plan type</p>;
        }
    };

    return (
        <div>
            <h2>{planType ? planType.charAt(0).toUpperCase() + planType.slice(1) : 'Invalid'} Insurance Details</h2>
            <form onSubmit={handleSubmit}>
                {renderFormFields()}
                <button type="submit">Submit</button>
            </form>
        </div>
    );
};

export default PlanTypeForm;

// import React, { useState } from 'react';
// import axios from 'axios';
// import { useNavigate, useLocation } from 'react-router-dom';

// const PlanTypeForm = () => {
//     const navigate = useNavigate();
//     const location = useLocation();
//     const { planType = '' } = location.state || {};
//     console.log(planType);

//     const [formData, setFormData] = useState({
//         annual_income: '',
//         health_history: '',
//         smoking_status: '',
//         hobbies_lifestyle: '',
//         medical_exam_details: '',
//         property_address: '',
//         year_built: '',
//         residence_type: '',
//         square_footage: '',
//         security_systems: '',
//         height_weight: '',
//         existing_conditions: '',
//         primary_physician: '',
//         medications: '',
//         hospital_preferences: '',
//         vin: '',
//         current_mileage: '',
//         previous_claims: '',
//         usage_type: '',
//         usage_frequency: '',
//     });

//     const handleChange = (e) => {
//         setFormData({ ...formData, [e.target.name]: e.target.value });
//     };

//     const handleSubmit = (e) => {
//         e.preventDefault();
//         console.log(formData);
//         console.log.apply(planType);
//         axios.post(`http://localhost:8080/api/${planType}-insurance`, formData)
//             .then(response => {
//                 alert('Details submitted successfully');
//                 navigate('/customer/success-page'); // Navigate to a success page or dashboard
//             })
//             .catch(error => console.error(error));
//     };

//     const renderFormFields = () => {
//         switch (planType) {
//             case 'life':
//                 return (
//                     <>
//                         <label>
//                             Annual Income:
//                             <input type="number" name="annual_income" value={formData.annual_income} onChange={handleChange} required />
//                         </label>
//                         <label>
//                             Health History:
//                             <textarea name="health_history" value={formData.health_history} onChange={handleChange} required />
//                         </label>
//                         <label>
//                             Smoking Status:
//                             <select name="smoking_status" value={formData.smoking_status} onChange={handleChange} required>
//                                 <option value="non-smoker">Non-Smoker</option>
//                                 <option value="smoker">Smoker</option>
//                             </select>
//                         </label>
//                         <label>
//                             Hobbies and Lifestyle:
//                             <textarea name="hobbies_lifestyle" value={formData.hobbies_lifestyle} onChange={handleChange} required />
//                         </label>
//                         <label>
//                             Medical Exam Details:
//                             <textarea name="medical_exam_details" value={formData.medical_exam_details} onChange={handleChange} required />
//                         </label>
//                     </>
//                 );
//             case 'home':
//                 return (
//                     <>
//                         <label>
//                             Property Address:
//                             <input type="text" name="property_address" value={formData.property_address} onChange={handleChange} required />
//                         </label>
//                         <label>
//                             Year Built:
//                             <input type="number" name="year_built" value={formData.year_built} onChange={handleChange} required />
//                         </label>
//                         <label>
//                             Type of Residence:
//                             <select name="residence_type" value={formData.residence_type} onChange={handleChange} required>
//                                 <option value="single-family">Single-family</option>
//                                 <option value="condo">Condo</option>
//                                 <option value="townhouse">Townhouse</option>
//                                 <option value="multi-family">Multi-family</option>
//                             </select>
//                         </label>
//                         <label>
//                             Square Footage:
//                             <input type="number" name="square_footage" value={formData.square_footage} onChange={handleChange} required />
//                         </label>
//                         <label>
//                             Security Systems:
//                             <select name="security_systems" value={formData.security_systems} onChange={handleChange} required>
//                                 <option value="yes">Yes</option>
//                                 <option value="no">No</option>
//                             </select>
//                         </label>
//                     </>
//                 );
//             case 'health':
//                 return (
//                     <>
//                         <label>
//                             Height and Weight:
//                             <input type="text" name="height_weight" value={formData.height_weight} onChange={handleChange} required />
//                         </label>
//                         <label>
//                             Existing Medical Conditions:
//                             <textarea name="existing_conditions" value={formData.existing_conditions} onChange={handleChange} required />
//                         </label>
//                         <label>
//                             Primary Care Physician:
//                             <input type="text" name="primary_physician" value={formData.primary_physician} onChange={handleChange} required />
//                         </label>
//                         <label>
//                             Medications:
//                             <textarea name="medications" value={formData.medications} onChange={handleChange} required />
//                         </label>
//                         <label>
//                             Hospital Preferences:
//                             <textarea name="hospital_preferences" value={formData.hospital_preferences} onChange={handleChange} required />
//                         </label>
//                     </>
//                 );
//             case 'vehicle':
//                 return (
//                     <>
//                         <label>
//                             Vehicle Identification Number (VIN):
//                             <input type="text" name="vin" value={formData.vin} onChange={handleChange} required />
//                         </label>
//                         <label>
//                             Current Mileage:
//                             <input type="number" name="current_mileage" value={formData.current_mileage} onChange={handleChange} required />
//                         </label>
//                         <label>
//                             Previous Claims:
//                             <textarea name="previous_claims" value={formData.previous_claims} onChange={handleChange} required />
//                         </label>
//                         <label>
//                             Usage Type:
//                             <select name="usage_type" value={formData.usage_type} onChange={handleChange} required>
//                                 <option value="personal">Personal</option>
//                                 <option value="commercial">Commercial</option>
//                             </select>
//                         </label>
//                         <label>
//                             Vehicle Usage Frequency:
//                             <select name="usage_frequency" value={formData.usage_frequency} onChange={handleChange} required>
//                                 <option value="daily">Daily</option>
//                                 <option value="weekly">Weekly</option>
//                                 <option value="occasional">Occasional</option>
//                             </select>
//                         </label>
//                     </>
//                 );
//             default:
//                 return <p>Invalid plan type</p>;
//         }
//     };

//     return (
//         <div>
//             <h2>{planType ? planType.charAt(0).toUpperCase() + planType.slice(1) : 'Invalid'} Insurance Details</h2>
//             <form onSubmit={handleSubmit}>
//                 {renderFormFields()}
//                 <button type="submit">Submit</button>
//             </form>
//         </div>
//     );
// };

// export default PlanTypeForm;
